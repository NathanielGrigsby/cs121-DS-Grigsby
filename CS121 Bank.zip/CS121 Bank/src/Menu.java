import java.util.Scanner;
public class Menu {
    Scanner console = new Scanner(System.in);
    public void printHeader(){
        System.out.println("|---------------------|");
        System.out.println("|  Welcome to CS 121  |");
        System.out.println("|       Banking       |");
        System.out.println("|---------------------|");
    }
    //This method gives the first set of selections
    public void printMenu(){
        while(true){
            String selection;
            System.out.println("\nPlease make a selection: \n"
                + "1) Access account \n"
                + "2) Open a new account \n"
                + "3) Exit ");
            //Read user input for option selection
            selection = console.nextLine();
            if(selection.equals("1")){
                this.accessAccount();
            }else if(selection.equals("2")){
                this.createNewAccount();
            }else if(selection.equals("3")){
                System.out.println("Thank you for using CS 121 Banking App");
                System.exit(0);
            }else{
                System.out.println("Invalid Entry");
            }
        }
    }
    //Add accessAccount and createNewAccount methods
    public void accessAccount(){
        String PIN;
        String selection;
        System.out.println("Enter your PIN");
        PIN = console.nextLine();
        if(PIN.equals(userPIN)) {
            System.out.println("Which account do you want to access?\n");
            System.out.println("1) Checking account\n");
            System.out.println("2) Savings account\n");
            System.out.println("3) Exit");
            selection = console.nextLine();
            //If loop to access account balances
            if (selection.equals("1")) {
                this.checkingBalance();
            } else if (selection.equals("2")) {
                this.savingsBalance();
            }else if(selection.equals("3")){
                System.out.println("Thank you for using CS 121 Banking App");
                System.exit(0);
            }else{
                System.out.println("Invalid Entry");
            }
        }else{
            System.out.println("Invalid PIN");
        }
    }
    public void createNewAccount(){

    }
}
